class UserModel {
  String userId;
  UserModel({this.userId});
}
